package com.jackson_siro.visongbook_int;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;

public class About extends ActionBarActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.about);
	}

}
