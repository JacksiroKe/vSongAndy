package com.jackson_siro.visongbook_int.tools;

import com.jackson_siro.visongbook_int.Aaa;
import com.jackson_siro.visongbook_int.R;

import android.annotation.SuppressLint;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TaskStackBuilder;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.NotificationCompat;
import android.telephony.SmsManager;
import android.telephony.SmsMessage;
import android.util.Log;
import android.widget.Toast;

@SuppressLint("ShowToast")
public class IncomingMessage extends BroadcastReceiver
{
  
	NotificationCompat.Builder notification;
	PendingIntent pIntent;
	NotificationManager manager;
	Intent resultIntent;
	TaskStackBuilder stackBuilder;
    String notificationMsg;
    String notificationTitle;
    Uri ringToneUri;
	
  final SmsManager sms = SmsManager.getDefault();

  public void onReceive(Context paramContext, Intent paramIntent)
  {
	  SharedPreferences.Editor editor = PreferenceManager.getDefaultSharedPreferences(paramContext.getApplicationContext()).edit();
	  
	  if (!PreferenceManager.getDefaultSharedPreferences(paramContext.getApplicationContext()).getBoolean("js_vsb_is_paid", false))
		{
	     
		  Bundle localBundle = paramIntent.getExtras();
		    if (localBundle != null) {}
		    for (;;)
		    {
		      int i;
		      String sender;
		      String message;
		      try {
		        Object[] arrayOfObject = (Object[])localBundle.get("pdus");
		        i = 0;
		        if (i >= arrayOfObject.length) {
		          return;
		        }
		        SmsMessage localSmsMessage = SmsMessage.createFromPdu((byte[])arrayOfObject[i]);
		        sender = localSmsMessage.getDisplayOriginatingAddress();
		        message = localSmsMessage.getDisplayMessageBody();
		        Log.i("SmsReceiver", "senderNum: " + sender + "; message: " + message);
		        
		        if (sender.equalsIgnoreCase("MPESA")) {
			        if (message.contains("JACKSON SIRO"))
			        {
			      	  	editor.putBoolean("js_vsb_is_paid", true);
			  			editor.commit();
			  			//Toast.makeText(paramContext, "vSongBook Int Has been Activated!", Toast.LENGTH_LONG).show();
			  			//new CreateNotification(paramContext).createNotification(1);
			  			notificationTitle = "vSongBook Int has been Activated!";
			            notificationMsg = "God bless you! vSongBook Int has been activated by M-PESA. Enjoy";
		
						NewNotification(paramContext, notificationTitle, notificationMsg);
			        }
		         } 
		           else if (sender.equalsIgnoreCase("AirtelMoney")) {
		 	        if (message.contains("JACKSON SIRO"))  {
		 	      	  	editor.putBoolean("js_vsb_is_paid", true);
		 	  			editor.commit();
		 	  			//Toast.makeText(paramContext, "vSongBook Int Has been Activated!", Toast.LENGTH_LONG).show();
		 	  			notificationTitle = "vSongBook Int has been Activated!";
		 	            notificationMsg = "God bless you! vSongBook Int has been activated by AirtelMoney. Enjoy";
		
						NewNotification(paramContext, notificationTitle, notificationMsg);
		 	        }
		          } else if (sender.contains("711474787")) {
		  	        if (message.contains("Jackson Siro")) {
		  	      	  	editor.putBoolean("js_vsb_is_paid", true);
		  	  			editor.commit();
		  	  			//Toast.makeText(paramContext, "vSongBook Int Has been Activated!", Toast.LENGTH_LONG).show();
			  	  		notificationTitle = "vSongBook Int has been Activated!";
			            notificationMsg = "God bless you! vSongBook Int has been activated by the Developer. Enjoy";
		
						NewNotification(paramContext, notificationTitle, notificationMsg);
		  	        }
		           }  else if (sender.contains("731973180")) {
		     	        if (message.contains("Jackson Siro")) {
		      	      	  	editor.putBoolean("js_vsb_is_paid", true);
		      	  			editor.commit();
		      	  			//Toast.makeText(paramContext, "vSongBook Int Has been Activated!", Toast.LENGTH_LONG).show();
		      	  		notificationTitle = "vSongBook Int has been Activated!";
		                notificationMsg = "God bless you! vSongBook Int has been activated by the Developer. Enjoy";
		
						NewNotification(paramContext, notificationTitle, notificationMsg);
		      	        }
		               }
		        
		      } catch (Exception localException) {
		        Log.e("SmsReceiver", "Exception smsReceiver" + localException);
		        return;
		      }
      
     }
    }
  }
  

	public void NewNotification(Context context, String strtitle, String strmessage) {
		Intent intent = new Intent(context, Aaa.class);
		intent.putExtra("title", strtitle);
		intent.putExtra("text", strmessage);
		PendingIntent pIntent = PendingIntent.getActivity(context, 0, intent,
				PendingIntent.FLAG_UPDATE_CURRENT);
		this.ringToneUri = Uri.parse("android.resource://" + 
				context.getPackageName() + "/raw/tweeting");
		// Create Notification using NotificationCompat.Builder
		NotificationCompat.Builder builder = new NotificationCompat.Builder(context)
				.setSmallIcon(R.drawable.ic_launcher)
				.setTicker(strmessage)
				.setContentTitle(strtitle)
				.setSound(ringToneUri)
				.setContentText(strmessage)
				.addAction(R.drawable.ic_launcher, "Continue Singing", pIntent)
				.setContentIntent(pIntent)
				.setAutoCancel(true);

		// Create Notification Manager
		NotificationManager notificationmanager = (NotificationManager) context
				.getSystemService(Context.NOTIFICATION_SERVICE);
		// Build Notification with Notification Manager
		notificationmanager.notify(0, builder.build());

	}
  
}
