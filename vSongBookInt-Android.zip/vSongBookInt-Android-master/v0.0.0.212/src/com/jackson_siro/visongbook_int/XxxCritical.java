package com.jackson_siro.visongbook_int;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.widget.RelativeLayout;

public class XxxCritical extends ActionBarActivity {
	RelativeLayout MySong;
	
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.critical);		
		setTitle("vSongBook Int has Terminated");
	}
		
	public void onExit(View v) {
		finish();
	}

}